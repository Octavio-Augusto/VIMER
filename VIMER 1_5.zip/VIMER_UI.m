function VIMER_UI

%%%%%%%%%% **************************************************** %%%%%%%%%%
%%%%%%%%%%                         VIMER                        %%%%%%%%%%
%%%%%%%%%%    Volume Integral Model of the Electric Response    %%%%%%%%%%
%%%%%%%%%%                     Versi�n (1.5.1)                  %%%%%%%%%%
%%%%%%%%%% **************************************************** %%%%%%%%%%
%%%%%%%%%% This Method computes the electric response of a body %%%%%%%%%%
%%%%%%%%%% in a half-space using a volume integral as the       %%%%%%%%%%
%%%%%%%%%% solution for the differential equation. The integral %%%%%%%%%%
%%%%%%%%%% is evaluated with an specific Gaussian quadrature    %%%%%%%%%%
%%%%%%%%%% used in 3D bodies called cubature.                   %%%%%%%%%%
%%%%%%%%%% This code is part of the submited paper:             %%%%%%%%%%
%%%%%%%%%% A computational package to compute electrical        %%%%%%%%%%
%%%%%%%%%% resistivity tomography response for regular bodies   %%%%%%%%%%
%%%%%%%%%% immersed in a homogeneous half-space.                %%%%%%%%%%
%%%%%%%%%% GEO-2022-0058                                        %%%%%%%%%%  
%%%%%%%%%% Authors:                                             %%%%%%%%%%
%%%%%%%%%% M.S. Hector Octavio Augusto Hernandez Contreras &    %%%%%%%%%%
%%%%%%%%%% Ph.D. Elsa Leticia Flores M�rquez                    %%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
clc


f1=figure('toolbar','none','visible','off','Position',[228,10,950,600]);


TTL=uicontrol('style','text','string',...
    'Volume Integral Model of the Electric Response.','position',...
    [220,560,450,25],'FontSize', 14);

Inpt1_txt=uicontrol('style','text','string','Number of electrodes:',...
    'position',[10,520,147,20],'FontSize', 11);
Inpt1=uicontrol('style','edit','string','42','position',...
      [250,520,90,20],'FontSize', 11);

Inpt2_txt=uicontrol('style','text','string',...
    'Distance between electrodes [m]:','position',[10,490,220,20],...
    'FontSize', 11);
Inpt2=uicontrol('style','edit','string','1','position',...
      [250,490,90,20],'FontSize', 11);
  
Inpt3_txt=uicontrol('style','text','string',...
    'Angle of the array [�]:','position',[10,460,140,20],'FontSize', 11);
Inpt3=uicontrol('style','edit','string','90','position',...
      [250,460,90,20],'FontSize', 11);

Inpt4_txt=uicontrol('style','text','string',...
    'Resitivity of the Half-space [ohmm]:','position',[10,430,240,20],...
    'FontSize', 11);
Inpt4=uicontrol('style','edit','string','100','position',...
      [250,430,90,20],'FontSize', 11);  
  
Inpt5_txt=uicontrol('style','text','string',...
    'Number of bodies in the Half-space:','position',[10,400,240,20],...
    'FontSize', 11);
Inpt5=uicontrol('style','edit','string','1','position',...
      [250,400,90,20],'FontSize', 11,'Callback',@Inpt5_CB);

Inpt6_txt=uicontrol('style','text','string',...
    'Select array:','position',[10,367,120,20],'FontSize', 11);
Inpt6=uicontrol('style','popupmenu','string',...
    {'Wenner','Dipole-Dipole','Pole-Dipole','Pole-Pole'},'position',...
      [250,370,90,20],'FontSize', 11,'callback',@Inpt6_CB);
TA=1;

align([Inpt1_txt,Inpt2_txt,Inpt3_txt,Inpt4_txt,Inpt5_txt,Inpt6_txt],...
    'Right','none');  

P=uipanel(f1,'position',[0.01,0.02,0.35,0.55]);
PTtl=uicontrol(P,'style','text','string',...
    'Dimensions of each body in the half-space.',...
    'position',[10,300,300,20],'FontSize', 11);
TABS=uitabgroup(P,'position',[0.01,0.01,0.95,0.90]);

TAB(1)=uitab(TABS,'title','B-1');
        row1=uicontrol(TAB(1),'style','text','position',[5,260,145,25],...
            'string','Centroid x coord. [m]:','FontSize', 11);
        Row1(1)=uicontrol(TAB(1),'style','edit','string','21','position',...
            [210,260,80,25],'FontSize', 11);
        row2=uicontrol(TAB(1),'style','text','position',[5,220,145,25],...
            'string','Centroid y coord. [m]:','FontSize', 11);
        Row2(1)=uicontrol(TAB(1),'style','edit','string','0','position',...
            [210,220,80,25],'FontSize', 11);
        row3=uicontrol(TAB(1),'style','text','position',[5,180,75,25],...
            'string','Height [m]:','FontSize', 11);
        Row3(1)=uicontrol(TAB(1),'style','edit','string','5','position',...
            [210,180,80,25],'FontSize', 11);
        row4=uicontrol(TAB(1),'style','text','position',[5,140,75,25],...
            'string','Width [m]:','FontSize', 11);
        Row4(1)=uicontrol(TAB(1),'style','edit','string','5','position',...
            [210,140,80,25],'FontSize', 11);
        row5=uicontrol(TAB(1),'style','text','position',[5,100,77,25],...
            'string','Length [m]:','FontSize', 11);
        Row5(1)=uicontrol(TAB(1),'style','edit','string','5','position',...
            [210,100,80,25],'FontSize', 11);
        row6=uicontrol(TAB(1),'style','text','position',[5,60,75,25],...
            'string','Depth [m]:','FontSize', 11);
        Row6(1)=uicontrol(TAB(1),'style','edit','string','5','position',...
            [210,60,80,25],'FontSize', 11);
        row7=uicontrol(TAB(1),'style','text','position',[5,20,205,25],...
            'string','Resistivity of the body [ohmm]:','FontSize', 11);
        Row7(1)=uicontrol(TAB(1),'style','edit','string','300','position',...
            [210,20,80,25],'FontSize', 11);
        
        align([row1,row2,row3,row4,row5,row6,row7],'Right','none');
        
IMG1=imread('ArrayImg.png');
IMG2=imread('BodyImg.png');
subplot(2,2,2), imshow(IMG1)
subplot(2,2,4), imshow(IMG2)
        
Button=uicontrol('style','pushbutton','string','Run!','position',...
    [690,10,70,30],'FontSize', 11,'callback',@Button_CB);
Button2=uicontrol('style','pushbutton','string','About...','position',...
    [770,10,70,30],'FontSize', 11,'callback',@Button2_CB);
Button3=uicontrol('style','pushbutton','string','Exit','position',...
    [850,10,70,30],'FontSize', 11,'callback',@Button3_CB);

f1.Units='normalized';
Inpt1_txt.Units='normalized';
Inpt1.Units='normalized';
Inpt2_txt.Units='normalized';
Inpt2.Units='normalized';
Inpt3_txt.Units='normalized';
Inpt3.Units='normalized';
Inpt4_txt.Units='normalized';
Inpt4.Units='normalized';
Inpt5_txt.Units='normalized';
Inpt5.Units='normalized';
Inpt6_txt.Units='normalized';
Inpt6.Units='normalized';
P.Units='normalized';
PTtl.Units='normalized';
TABS.Units='normalized';
TAB.Units='normalized';
row1.Units='normalized';
Row1.Units='normalized';
row2.Units='normalized';
Row2.Units='normalized';
row3.Units='normalized';
Row3.Units='normalized';
row4.Units='normalized';
Row4.Units='normalized';
row5.Units='normalized';
Row5.Units='normalized';
row6.Units='normalized';
Row6.Units='normalized';
row7.Units='normalized';
Row7.Units='normalized';
Button.Units='normalized';
Button2.Units='normalized';
Button3.Units='normalized';
f1.Name='VIMER V.1.5';
movegui(f1,'center');
f1.Visible='on';
        

function Inpt6_CB(source,eventdata);
str=get(source,'string');
val=get(source,'value');
switch str{val}
    case 'Wenner'
        TA=1;
    case 'Dipole-Dipole'
        TA=2;
    case 'Pole-Dipole'
        TA=3;
    case 'Pole-Pole'
        TA=4;
end
end

    function Inpt5_CB(source,eventdata);
        str=get(source,'string');
        n=str2double(str);
        Integer=floor(n);
        ChkInt=n/Integer;
        if isnan(n)==1
            Error1
            return
        else if ChkInt~=1
                Error1
                return
        else if n>6
                Error5
                return
        else if n<=0
            Error2
            return
            end
            end
            end
        end
TABS=[];
TABS=uitabgroup(P,'position',[0.01,0.01,0.95,0.90]);
    for i=1:n;
        num=num2str(i);
        TAB(i)=uitab(TABS,'title',['B-',num]);
        row1=uicontrol(TAB(i),'style','text','position',[5,260,145,25],...
            'string','Centroid x coord. [m]:','FontSize', 11);
        Row1(i)=uicontrol(TAB(i),'style','edit','string',' ','position',...
            [210,260,80,25],'FontSize', 11);
        row2=uicontrol(TAB(i),'style','text','position',[5,220,145,25],...
            'string','Centroid y coord. [m]:','FontSize', 11);
        Row2(i)=uicontrol(TAB(i),'style','edit','string',' ','position',...
            [210,220,80,25],'FontSize', 11);
        row3=uicontrol(TAB(i),'style','text','position',[5,180,75,25],...
            'string','Height [m]:','FontSize', 11);
        Row3(i)=uicontrol(TAB(i),'style','edit','string',' ','position',...
            [210,180,80,25],'FontSize', 11);
        row4=uicontrol(TAB(i),'style','text','position',[5,140,75,25],...
            'string','Width [m]:','FontSize', 11);
        Row4(i)=uicontrol(TAB(i),'style','edit','string',' ','position',...
            [210,140,80,25],'FontSize', 11);
        row5=uicontrol(TAB(i),'style','text','position',[5,100,77,25],...
            'string','Length [m]:','FontSize', 11);
        Row5(i)=uicontrol(TAB(i),'style','edit','string',' ','position',...
            [210,100,80,25],'FontSize', 11);
        row6=uicontrol(TAB(i),'style','text','position',[5,60,75,25],...
            'string','Depth [m]:','FontSize', 11);
        Row6(i)=uicontrol(TAB(i),'style','edit','string',' ','position',...
            [210,60,80,25],'FontSize', 11);
        row7=uicontrol(TAB(i),'style','text','position',[5,20,205,25],...
            'string','Resistivity of the body [ohmm]:','FontSize', 11);
        Row7(i)=uicontrol(TAB(i),'style','edit','string',' ','position',...
            [210,20,80,25],'FontSize', 11);
        
       align([row1,row2,row3,row4,row5,row6,row7],'Right','none'); 
       
        TAB(i).Units='normalized';
        row1.Units='normalized';
        Row1(i).Units='normalized';
        row2.Units='normalized';
        Row2(i).Units='normalized';
        row3.Units='normalized';
        Row3(i).Units='normalized';
        row4.Units='normalized';
        Row4(i).Units='normalized';
        row5.Units='normalized';
        Row5(i).Units='normalized';
        row6.Units='normalized';
        Row6(i).Units='normalized';
        row7.Units='normalized';
        Row7(i).Units='normalized';

    end
    TABS.Units='normalized';
       
        
end

    function Button2_CB(source,eventdata)
            Msg;
    end
    function Button3_CB(source,eventdata)
        close all
        clear all
        clc
    end

    function Button_CB(source,eventdata)
        
        NE=str2double(get(Inpt1,'string'));
        a=str2double(get(Inpt2,'string'));
        deg=str2double(get(Inpt3,'string'));
        n=1; %Editable Number of Sub-levels for Wenner-Schlumberger
        rhom=str2double(get(Inpt4,'string'));
        N=str2double(get(Inpt5,'string'));
        
        for i=1:N
            xj(i)=str2double(get(Row1(i),'string'));
            yj(i)=str2double(get(Row2(i),'string'));
            h(i)=str2double(get(Row3(i),'string'));
            l(i)=str2double(get(Row4(i),'string'));
            w(i)=str2double(get(Row5(i),'string'));
            d(i)=str2double(get(Row6(i),'string'));
            rhoc(i)=str2double(get(Row7(i),'string'));
        end
      Positives=[NE,a,rhom];
      Chk=[Positives<=0];
      PositiveVectors=[h,l,w,d,rhoc];
      ChkV=[PositiveVectors<=0];
      Integer=floor(NE);
      ChkI=NE/Integer;
            if any(isnan([NE,a,deg,rhom,xj,yj,h,l,w,d,rhoc]))==1
               Error3
               return       
                else if NE<=4
               Error4
               return                                       
                else if any(Chk)==1
               Error2
               return
                else if ChkI~=1
               Error1
               return
                else if any(ChkV)==1
               Error2
               return
                    end
                    end
                    end
                    end                           
            end
 %%%%%%%Probably a For j=1:N          
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I=20; % Intensity
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Position of the First Electrode
xi=25000;
yi=25000;
%%%%% Coordinates (SCR) of the Geometric Center of the 1st Body
XA=xi+xj(1); YA=yi+yj(1); ZA=-d(1)-(h(1)/2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Electrode Line
E=Elect(xi,yi,NE,a,deg);
OS=[xi,yi]; % Origin of the system
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Nodes and Function Family. N=5,10,15; T=1,2,3,4,5
NN=10;
TT=2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch TA
       case 1
            
         D=WS(NE,n);           
         for J=1:N
             XA=xi+xj(J); YA=yi+yj(J);
             ZA=-d(J)-(h(J)/2);
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         Dr=rhoc(J)-rhom; %Resistivity Diference
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         % Limits
         ac=-w(J)/2; bc=w(J)/2; cc=-l(J)/2; dc=l(J)/2; ec=-h(J)/2;...
                fc=h(J)/2;
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         Z=FKernel4e(D,TA,E,XA,YA,ZA,NN,TT,ac,bc,cc,dc,ec,fc,I,Dr,rhom,...
             deg,OS);
         Zar{J}=Z;
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
         end
                       
            
       case 2
           
         D=DD(NE,n);
          for J=1:N
             XA=xi+xj(J); YA=yi+yj(J);
             ZA=-d(J)-(h(J)/2);
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         Dr=rhoc(J)-rhom; %Resistivity Diference
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         % Limits
         ac=-w(J)/2; bc=w(J)/2; cc=-l(J)/2; dc=l(J)/2; ec=-h(J)/2;...
                fc=h(J)/2;
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         Z=FKernel4e(D,TA,E,XA,YA,ZA,NN,TT,ac,bc,cc,dc,ec,fc,I,Dr,rhom,...
             deg,OS);
         Zar{J}=Z;
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
          end
          
         
       case 3
            
            D=PD(NE,n);
            for J=1:N
             XA=xi+xj(J); YA=yi+yj(J);
             ZA=-d(J)-(h(J)/2);
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         Dr=rhoc(J)-rhom; %Resistivity Diference
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         % Limits
         ac=-w(J)/2; bc=w(J)/2; cc=-l(J)/2; dc=l(J)/2; ec=-h(J)/2;...
                fc=h(J)/2;
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         Z=FKernel3e(D,TA,E,XA,YA,ZA,NN,TT,ac,bc,cc,dc,ec,fc,I,Dr,rhom,...
             deg,OS);
         Zar{J}=Z;
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
         end
            
       case 4
            
            D=PP(NE,n);
            for J=1:N
             XA=xi+xj(J); YA=yi+yj(J);
             ZA=-d(J)-(h(J)/2);
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         Dr=rhoc(J)-rhom; %Resistivity Diference
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         % Limits
         ac=-w(J)/2; bc=w(J)/2; cc=-l(J)/2; dc=l(J)/2; ec=-h(J)/2;...
                fc=h(J)/2;
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         Z=FKernel2e(D,TA,E,XA,YA,ZA,NN,TT,ac,bc,cc,dc,ec,fc,I,Dr,rhom,...
             deg,OS);
         Zar{J}=Z;
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%            
         end
            
end

Rx=Zar{1}(:,1);
Ry=Zar{1}(:,2);
RX=sortn(Rx);
RY=sortn(Ry);

Zi=imgmap2(RX,RY,Zar,rhom,J);

%'toolbar','none','menu','none',
f2=figure('WindowStyle','normal',...
    'Position',[228,10,910,512]);
f2.Name='Pseudo Resistivity Section';
movegui(f2,'center');      
colormap('jet')
contourf(RX,RY,Zi,20,'linecolor','none')
set(gca,'FontSize',14)
colorbar
hold on
scatter(Z(:,1),Z(:,2),2,[1 1 1])
hold off
Title=uicontrol('style','text','string','Pseudo-resistivity section',...
    'position',[350,490,200,20],'FontSize', 12);
DEPTH=uicontrol('style','text','string','Depth [m]',...
    'position',[20,480,70,20],'FontSize', 12);
METERS=uicontrol('style','text','string','Distance [m]',...
    'position',[400,5,120,20],'FontSize', 12);
RHO=uicontrol('style','text','string','Resistivity [Ohm.m]',...
    'position',[700,490,150,20],'FontSize', 12);
Save=uicontrol('style','pushbutton','string','Save...','position',...
    [800,10,60,25],'callback',@Save_CB,'FontSize', 12);

%assignin('base','R',Zi)

            function Save_CB(source,event)
                    prompt={'Name of the file:'};
                    dlg_title='Save file';
                    defaultanswer={'Results.dat'};
                    M=inputdlg(prompt,dlg_title,[1 40],defaultanswer);
                    N=M{1};
                    fid=fopen(N,'w');
                    row=length(Zi(:,1));
                    col=length(Zi(1,:));
                    for ii=row:-1:1
                        for jj=1:col
                            fprintf(fid,'%6.2f,%6.2f,%6.2f\n',...
                                RX(jj),RY(ii),Zi(ii,jj));
                        end
                            
                    end
                    fclose(fid);
            end

    end
      

    
        
    


        
end
