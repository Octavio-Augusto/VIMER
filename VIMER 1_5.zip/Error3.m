function Error3

dlgname='Error 3';
T1='Invalid Data.';
T2=' ';
T3='Please enter numeric values';
T4='';
T5='             Click "Ok" to continue...';
helpstring=char(T1,T2,T3,T4,T5);
uiwait(msgbox(helpstring,dlgname,'modal'));

end