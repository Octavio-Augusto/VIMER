function Error6

dlgname='Error 6';
T1='No Data!';
T2=' ';
T3='No data to save!!';
T4='';
T5='             Click "Ok" to continue...';
helpstring=char(T1,T2,T3,T4,T5);
uiwait(msgbox(helpstring,dlgname,'modal'));

end