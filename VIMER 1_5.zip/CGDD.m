
function [A,B,M,N,Ze]=CGDD(i,j,k,E,D)
% Coordinates Generator

%i=1; %Line, #Cuad.
%j=1; %Column, Sub-L
%k=1; %Matrix, Level


A=E(D{k}.S(i+1,j),:);
A(1,3)=0;
B=E(D{k}.S(i,j),:);
B(1,3)=0;
M=E(D{k}.S(i+2,j),:);
M(1,3)=0;
N=E(D{k}.S(i+3,j),:);
N(1,3)=0;

n=j;

% Median Depth of investigation (Dipole-Dipole)

ZeLDD=[0.173;0.186;0.189;0.190;0.190;0.;0.220;0.224];

VL=N-B;
VL2=VL/2;
Ze=B+VL2;
L=sqrt(VL(1)^2+VL(2)^2);
Ze(1,3)=-L*ZeLDD(n);

