function X=sortn(Rx)

Lx=length(Rx);
j=1;
while Lx>0
    ind=(1);
    Ax=Rx(ind);
    i=1;
    ii=Lx;
    while ii>1
          if Ax-Rx(i+1)==0
             Rx(i+1)=[];            
             i=i-1;                    
          elseif Ax-Rx(i+1)>0
             Ax=Rx(i+1);
             ind=i+1;          
          end
          i=i+1;
          ii=ii-1;
    end
   X(j)=Ax;
   Rx(ind)=[];
   Lx=length(Rx);
   j=j+1;
end

end