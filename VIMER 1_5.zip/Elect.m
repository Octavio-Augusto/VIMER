function E=Elect(xi,yi,NE,a,D)

% Coordenadas de los electrodos, "x" crece hacia el este, "y" crece hacia
% el norte, xi,yi coordenadas del primer electrodo, NE n�mero de electrodos
% a separaci�n entre electrodos, D declinaci�n con respecto al norte de la
% l�nea de electrodos en grados.

D=D*pi/180;
dy=cos(D)*a;
dx=sin(D)*a;
E=zeros(NE,2);
E(1,1:2)=[xi,yi];
for i=2:NE
    E(i,1)=E(i-1,1)+dx;
    E(i,2)=E(i-1,2)+dy;
end