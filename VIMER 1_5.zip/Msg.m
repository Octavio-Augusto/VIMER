function Msg

dlgname='WELCOME';
T1='       Volume Integral Model of the Electric Response (VIMER).';
T2='This is an open source code, feel free to use, modify an contribute.';
T3='';
T4=' ';
T5='Enter the parameters of the body in their corresponding fields.';
T6='So far, only bodies with parallel faces can be modeled.';
T7=' ';
T8=' ';
T9='                                    Click "Ok" to continue';
helpstring=char(T1,T2,T3,T4,T5,T6,T7,T8,T9);
uiwait(msgbox(helpstring,dlgname,'modal'));

end