function [A,M,Ze]=CGPP(i,j,k,E,D)
% Coordinates Generator

%i=1; %Line, #Cuad.
%j=1; %Column, Sub-L
%k=1; %Matrix, Level


A=E(D{k}.S(i,j),:);
A(1,3)=0;
M=E(D{k}.S(i+1,j),:);
M(1,3)=0;

n=j;

% Median Depth of investigation (Pole-Pole)

ZeLPP=0.867;

VL=M-A; %Vector L, seg�n el tipo de arreglo se restan las posiciones de los electrodos en los extremos
VL2=VL/2; 
Ze=A+VL2; % Posici�n en superficie del punto de atribuci�n (en este caso centro del arreglo)
L=sqrt(VL(1)^2+VL(2)^2);
Ze(1,3)=-L*ZeLPP(n);
