function Error5

dlgname='Error 5';
T1='Invalid Data.';
T2=' ';
T3='Please enter 6 or less bodies for efficiency';
T4='';
T5='             Click "Ok" to continue...';
helpstring=char(T1,T2,T3,T4,T5);
uiwait(msgbox(helpstring,dlgname,'modal'));

end