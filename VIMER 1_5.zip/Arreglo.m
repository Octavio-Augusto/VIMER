function [NE,a,D,TA,n]=Arreglo

prompt={'Number of Electrodes:','Distance Between Electrodes [m]:'...
    ,'Angle of the Array:','Kind of Array:',...
    'Factor n:'};
dlg_title='Electrode Line';
defaultanswer={'21','1','90','1','1'};
d=inputdlg(prompt,dlg_title,[1 40],defaultanswer);
         
l=length(d);
if l>0
NE=str2double(d(1));
a=str2double(d(2));
D=str2double(d(3));
TA=str2double(d(4));
n=str2double(d(5));
else
NE=nan;
a=nan;
D=nan;
TA=nan;
n=nan;    
end
end