function Z=FKernel4e(D,TA,E,XA,YA,ZA,NN,TT,ac,bc,cc,dc,ec,fc,I,Dr,rhom,deg,OS)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Niv=length(D); % Number of leves / N�mero de niveles
Long=length(D{1}.S);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
jj=1; % Total Operations Counter / Contador total de operaciones
J=1;
wb=waitbar(0,'Please wait...');
for kkk=1:Niv
    Subniv=length(D{kkk}.S(1,:)); % Number of Sub-Leves / N�mero de sub-niveles
    for jjj=1:Subniv    
    ii=1;
    iii=1;
    Logic=(D{kkk}.S(iii,jjj)==0);
         while iii<=Long && Logic==0
             if TA==1
                [A,B,M,N,Ze]=CGWS(iii,jjj,kkk,E,D);
             else
                [A,B,M,N,Ze]=CGDD(iii,jjj,kkk,E,D); 
             end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Coordinates of the Mesured Point / Coordenadas del Punto Medido
xp=Ze(1); yp=Ze(2); zp=Ze(3); %%%%% SCR
x0p=Ze(1)-XA;y0p=Ze(2)-YA;z0p=Ze(3)-ZA; %%%%% SCC
a=[XA YA ZA]; %%%%% Vector a (SCR)
r=[xp yp zp]; %%%%% Vector r (SCR)
r0=-a+r; %%%%% Vector r0 (SCC)
%%%%% Coordinates of the Electrodes (A,B,M,N)
xsa=A(1); ysa=A(2); zsa=A(3); %%%%% A (SCR)
xsb=B(1); ysb=B(2); zsb=B(3); %%%%% B (SCR)
xm=M(1); ym=M(2); zm=M(3); %%%%% M (SCR)
xn=N(1); yn=N(2); zn=N(3); %%%%% N (SCR)
x0m=xm-XA;
y0m=ym-YA;
z0m=zm-ZA;
x0n=xn-XA;
y0n=yn-YA;
z0n=zn-ZA;
x0sa=xsa-XA;
y0sa=ysa-YA;
z0sa=zsa-ZA;
x0sb=xsb-XA;
y0sb=ysb-YA;
z0sb=zsb-ZA;

ram=sqrt((xsa-xm).^2+(ysa-ym).^2); % Distance A-M
rbm=sqrt((xsb-xm).^2+(ysb-ym).^2); % Distance B-M
ran=sqrt((xsa-xn).^2+(ysa-yn).^2); % Distance A-N
rbn=sqrt((xsb-xn).^2+(ysb-yn).^2); % Distance B-N

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%% AM

IvAM=-Cubatura(x0sa,y0sa,x0m,y0m,ZA,NN,TT,ac,bc,cc,dc,ec,fc);

%%%%%%%%%% BM

IvBM=Cubatura(x0sb,y0sb,x0m,y0m,ZA,NN,TT,ac,bc,cc,dc,ec,fc);

%%%%%%%%%% AN

IvAN=Cubatura(x0sa,y0sa,x0n,y0n,ZA,NN,TT,ac,bc,cc,dc,ec,fc);

%%%%%%%%%% BN

IvBN=-Cubatura(x0sb,y0sb,x0n,y0n,ZA,NN,TT,ac,bc,cc,dc,ec,fc);

Iv=IvAM+IvBM+IvAN+IvBN;

DV=(I/(4*pi^2))*Dr*Iv; % Potential Difference / Diferencia de Potencial

k=(2*pi)/((1/ram)-(1/rbm)-(1/ran)+(1/rbn));
ra=rhom+(DV/I)*k;

%%%%%%Ze

Ra{kkk}.Ra(ii,jjj)=ra;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Projections on surface / Proyecciones en superficie
Za=[Ze(1),Ze(2)];
Zb=OS;
Zc=Za-Zb;
  if sin(deg*pi/180)==0
    Cp=norm(Zc)*sign(Zc(2)); 
  else
    Cp=norm(Zc)*sign(Zc(1));
  end
%%%%% XYZ File Format / Formato XYZ
Z(jj,1)=Cp;
Z(jj,2)=Ze(3);
Z(jj,3)=ra;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
iii=iii+4;
ii=ii+1;
jj=jj+1;
if iii<=Long
    Logic=(D{kkk}.S(iii,jjj)==0);
end
         end                  
    end
    waitbar(kkk / Niv)
end
close(wb)
end