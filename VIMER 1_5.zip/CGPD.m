function [A,M,N,Ze]=CGPD(i,j,k,E,D)
% Coordinates Generator

%i=1; %Line, #Cuad.
%j=1; %Column, Sub-L
%k=1; %Matrix, Level


A=E(D{k}.S(i,j),:);
A(1,3)=0;
M=E(D{k}.S(i+1,j),:);
M(1,3)=0;
N=E(D{k}.S(i+2,j),:);
N(1,3)=0;

n=j;

% Median Depth of investigation (Pole-Dipole)

ZeLPD=[0.519,0.925,1.318,1.706,2.093,2.478,2.863,3.247];

VL=N-A; %Vector L, seg�n el tipo de arreglo se restan las posiciones de los electrodos en los extremos
VL2=VL/2; 
Ze=A+VL2; % Posici�n en superficie del punto de atribuci�n (en este caso centro del arreglo)
L=sqrt(VL(1)^2+VL(2)^2);
Ze(1,3)=-L*ZeLPD(n);
