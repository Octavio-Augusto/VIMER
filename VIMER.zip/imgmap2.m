function Zi=imgmap2(Rx,Ry,Rz,rhom,Nb)

x=length(Rx);
y=length(Ry);
z=length(Rz{1});
Zi=zeros(y,x);

  for L=1:Nb %Loop for Number of Bodies / Ciclo Para Varios Cuerpos
      Z{L}=zeros(y,x);
      for k=1:z
          for i=1:x
              if Rz{L}(k,1)==Rx(i)
                 break
                 %indx=i;
              end
          end
          for j=1:y
              if Rz{L}(k,2)==Ry(j)
                 break
                 %indy=j;
              end
          end  
          Z{L}(j,i)=Rz{L}(k,3);
        
      %%%%% Thikennign / Ensanchamiento
    
          if i<x
             Z{L}(j,i+1)=Rz{L}(k,3);
          end    
          if j<y && j>1 % && j>1
             Z{L}(j-1,i)=Rz{L}(k,3);% j+1 o j-1
          end
          if i<x && j<y && j>1 % &&j>1
             Z{L}(j-1,i+1)=Rz{L}(k,3);
          end
      %}
      end
  end


  for L=1:Nb
      Zi=Zi+Z{L};
  end

  %%%%% Background Resistivity
  for i=1:x
      for j=1:y
          if Zi(j,i)==0
             Zi(j,i)=Nb*rhom; % Nb*
          end
      end
  end
  Zi=Zi-(rhom*(Nb-1));
  
end