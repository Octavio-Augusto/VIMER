%%%%%%%%%% **************************************************** %%%%%%%%%%
%%%%%%%%%%                         VIMER                        %%%%%%%%%%
%%%%%%%%%%    Volume Integral Model of the Electric Response    %%%%%%%%%%
%%%%%%%%%%                     Versi�n (1.1)                    %%%%%%%%%%
%%%%%%%%%%      H�ctor Octavio Augusto Hern�ndez Contreras      %%%%%%%%%%
%%%%%%%%%%              Instituto de Geof�sica UNAM             %%%%%%%%%%
%%%%%%%%%% **************************************************** %%%%%%%%%%

clear all
close all
clc

Msg
Er=1;
while Er==1
[NE,a,dec,TA,n]=Arreglo;
                    if all(isnan([NE,a,dec,TA,n]))==1
                       clear all
                       return
                    else if any(isnan([NE,a,dec,TA,n]))==1
                         Error1
                         Er=1;
                    else if any(TA==[1,2,3,4])==0
                         Error2
                         Er=1;                        
                    else
                        Er=0;   
                    end
                    end
                    end
end
Er=1;
while Er==1
[xj,yj,h,l,w,d,rhom,rhoc]=Geom;
                    if all(isnan([xj,yj,h,l,w,d,rhom,rhoc]))==1
                       clear all
                       return 
                    else if any(isnan([xj,yj,h,l,w,d,rhom,rhoc]))==1
                       Error1
                       Er=1;
                    else
                       Er=0;
                    end
                    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I=20; % Intensity
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Position of the First Electrode
xi=25000;
yi=25000;
%%%%% Coordinates (SCR) of the Geometric Center of the Body
XA=xi+xj; YA=yi+yj; ZA=-d-(h/2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Electrode Line
E=Elect(xi,yi,NE,a,dec);
OS=[xi,yi];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Nodes and Function Family. N=5,10,15; T=1,2,3,4,5
NN=10;
TT=2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch TA
       case 1
            
            D=WS(NE,n);
            Ni=1;
            iZ=1;
            while Ni==1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Dr=rhoc-rhom; %Resistivity Diference
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Limits
            ac=-w/2; bc=w/2; cc=-l/2; dc=l/2; ec=-h/2; fc=h/2;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Kernel4e
            Zar{iZ}=Z;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Qstn=questdlg('Do you want to add another body?');
            Ni=(Qstn(1)=='Y');
               if Ni==1
                  Er=1;
                  while Er==1
                  [xj,yj,h,l,w,d,rhoc]=Geom2;
                       if all(isnan([xj,yj,h,l,w,d,rhoc]))==1
                          clear all
                          return
                       else if any(isnan([xj,yj,h,l,w,d,rhoc]))==1
                          Error1
                          Er=1;
                       else
                          Er=0;
                          XA=xi+xj; YA=yi+yj;
                          ZA=-d-(h/2);
                          iZ=iZ+1;
                       end
                       end
                  end                  
               end
            
            end
            
       case 2
            D=DD(NE,n);
            Ni=1;
            iZ=1;
            while Ni==1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Dr=rhoc-rhom; %Dif Res
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Limits
            ac=-w/2; bc=w/2; cc=-l/2; dc=l/2; ec=-h/2; fc=h/2;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Kernel4e
            Zar{iZ}=Z;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Qstn=questdlg('Do you want to add another body?');
            Ni=(Qstn(1)=='Y');
               if Ni==1
                  Er=1;
                  while Er==1
                  [xj,yj,h,l,w,d,rhoc]=Geom2;
                       if all(isnan([xj,yj,h,l,w,d,rhoc]))==1
                          clear all
                          return
                       else if any(isnan([xj,yj,h,l,w,d,rhoc]))==1
                          Error1
                          Er=1;
                       else
                          Er=0;
                          XA=xi+xj; YA=yi+yj;
                          ZA=-d-(h/2);
                          iZ=iZ+1;
                       end
                       end
                  end
               end
            end
       case 3
            
            D=PD(NE,n);
            Ni=1;
            iZ=1;
            while Ni==1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Dr=rhoc-rhom; %Dif Res
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Limits
            ac=-w/2; bc=w/2; cc=-l/2; dc=l/2; ec=-h/2; fc=h/2;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Kernel3e
            Zar{iZ}=Z;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Qstn=questdlg('Do you want to add another body?');
            Ni=(Qstn(1)=='Y');
               if Ni==1
                   Er=1;
                  while Er==1
                  [xj,yj,h,l,w,d,rhoc]=Geom2;
                       if all(isnan([xj,yj,h,l,w,d,rhoc]))==1
                          clear all
                          return
                       else if any(isnan([xj,yj,h,l,w,d,rhoc]))==1
                          Error1
                          Er=1;
                       else
                          Er=0;
                          XA=xi+xj; YA=yi+yj;
                          ZA=-d-(h/2);
                          iZ=iZ+1;
                       end
                       end
                  end
               end
            end
            
       case 4
            
            D=PP(NE,n);
            Ni=1;
            iZ=1;
            while Ni==1
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Dr=rhoc-rhom; %Dif Res
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Limits
            ac=-w/2; bc=w/2; cc=-l/2; dc=l/2; ec=-h/2; fc=h/2;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Kernel2e
            Zar{iZ}=Z;
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            Qstn=questdlg('Do you want to add another body?');
            Ni=(Qstn(1)=='Y');
               if Ni==1
                  Er=1;
                  while Er==1
                  [xj,yj,h,l,w,d,rhoc]=Geom2;
                       if all(isnan([xj,yj,h,l,w,d,rhoc]))==1
                          clear all
                          return
                       else if any(isnan([xj,yj,h,l,w,d,rhoc]))==1
                          Error1
                          Er=1;
                       else
                          Er=0;
                          XA=xi+xj; YA=yi+yj;
                          ZA=-d-(h/2);
                          iZ=iZ+1;
                       end
                       end
                  end
               end
            end
            
end

Rx=Zar{1}(:,1);
Ry=Zar{1}(:,2);
RX=sortn(Rx);
RY=sortn(Ry);

Zi=imgmap2(RX,RY,Zar,rhom,iZ);
figure('WindowStyle','normal');colormap('jet')
contourf(RX,RY,Zi,20,'linecolor','none')
colorbar
hold on
scatter(Z(:,1),Z(:,2),2,[1 1 1])
hold off