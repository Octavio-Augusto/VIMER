function Error1

dlgname='Error 1';
T1='Invalid Data.';
T2=' ';
T3='Only numeric values without spacing';
T4='';
T5='             Press "Ok" to continue';
helpstring=char(T1,T2,T3,T4,T5);
uiwait(msgbox(helpstring,dlgname,'modal'));

end