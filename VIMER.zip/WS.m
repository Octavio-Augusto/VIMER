function D=WS(NE,n)

% Funci�n WS, genera las coordenadas de los electrodos en el arreglo
% Wenner-Schlumberger con una abertura entre electrodos inicial "a", un n�mero
% m�ximo de subniveles N y un n�mero de electrodos NE
   
A=1; %Integer index for electrode spacing
N=1; %Integer index for sub-levels
LT=(NE-1)*A; % Longitude of electrode line
LA=2*(N*A)+A; % Longitude of electrode array (Alcance del Arreglo)
Nq=4; % Number of electrodes used per reading
k=1; % Counter to store matrix
d=zeros((NE-3)*4,1); % Memory allocation for d. NE-3=Number of cuadpoles,
% (NE-3)*4 for each electrode there's one index.
while LA<=LT
      j=1; %Counter to store vector
     while N<=n && LA<=LT             
           i=1; %Contador para avanzar en el �ndice de electrodo
           
          while LA<=NE
                %C1=1+((i-1)*A);                
                C1=i;
                P1=C1+N*A;                
                P2=C1+(A*(N+1));                
                C2=C1+(2*N*A)+A;                
                d(3*(i-1)+i:3*(i-1)+i+3)=[C1;P1;P2;C2];
                LA=C2+1; % Se rrecorre un lugar el arreglo
                i=i+1;                            
          end
        Sn(:,j)=d; %�ndices de sub-nivel
        d(:)=0;
        j=j+1;
        N=N+1; % Cambio de sub-nivel
        LA=2*(N*A)+A; % Longitud del Arreglo para cambio de n
     end
     N=1;
     A=A+1;
     LA=2*(N*A)+A;
     D{k}.S=Sn; % salvar en un txt
     clear Sn;
     k=k+1;
end
    
%end