function Error2

dlgname='Error 2';
T1='Invalid Data.';
T2=' ';
T3='The available options for Kind of Array are: 1,2,3 or 4';
T4='Check the User Guide for assistance';
T5='regarding Kind of Array.';
T6='';
T7='                   Press "Ok" to continue';
helpstring=char(T1,T2,T3,T4,T5,T6,T7);
uiwait(msgbox(helpstring,dlgname,'modal'));

end