
function [A,B,M,N,Ze]=CGWS(i,j,k,E,D)
% Coordinates Generator

%i=1; %Line, #Cuad.
%j=1; %Column, Sub-L
%k=1; %Matrix, Level


A=E(D{k}.S(i,j),:);
A(1,3)=0;
B=E(D{k}.S(i+3,j),:);
B(1,3)=0;
M=E(D{k}.S(i+1,j),:);
M(1,3)=0;
N=E(D{k}.S(i+2,j),:);
N(1,3)=0;

n=j;

% Median Depth of investigation (Wenner-Schlumberger)

ZeLWS=[0.173;0.186;0.189;0.190;0.190;0.191;0.191;0.191;0.191;0.191];

VL=B-A; %Vector L, seg�n el tipo de arreglo se restan las posiciones de los electrodos en los extremos
VL2=VL/2; 
Ze=A+VL2; % Posici�n en superficie del punto de atribuci�n (en este caso centro del arreglo)
L=sqrt(VL(1)^2+VL(2)^2);
Ze(1,3)=-L*ZeLWS(n);

