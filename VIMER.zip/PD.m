function D=PD(NE,n)

% Funci�n PD, genera las coordenadas de los electrodos en el arreglo
% Polo-Dipolo con una abertura entre electrodos inicial "a", un n�mero
% m�ximo de subniveles N y un n�mero de electrodos NE
   
A=1; %Integer index for electrode spacing
N=1; %Integer index for sub-levels
LT=(NE-1)*A; % Longitude of electrode line
LA=N*A+A; % Longitude of electrode array (Alcance del Arreglo)
Nq=3; % Number of electrodes used per reading
k=1; % Counter to store matrix
d=zeros((NE-2)*3,1); % Memory allocation for d. NE-2=Number of dipoles,
% (NE-2)*3 for each electrode there's one index.
while LA<=LT
      j=1; %Counter to store vector
     while N<=n && LA<=LT             
           i=1; %Contador para avanzar en el �ndice de electrodo
           
          while LA<=NE
                C1=i;                
                P1=i+N*A;
                P2=i+N*A+A;
                d(Nq*i-(Nq-1):Nq*i)=[C1;P1;P2];
                LA=P2+1; %Se recorre un lugar el arreglo
                i=i+1;           
          end
        Sn(:,j)=d; %�ndices de sub-nivel
        d(:)=0;
        j=j+1;
        N=N+1; % Cambio de sub-nivel
        LA=N*A+A; % Longitud del Arreglo para cambio de n
     end
     N=1;
     A=A+1;
     LA=N*A+A;
     D{k}.S=Sn;
     clear Sn;
     k=k+1;
end
    
%end