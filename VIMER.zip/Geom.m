function [xj,yj,h,l,w,d,rhom,rhoc]=Geom

      prompt={'Coord. x[m]:','Coord. y[m]:','Height (z axis)[m]:',...
          'Width (y axis)[m]:','Length (x axis)[m]:','Depth [m]:',...
          'Resistivity (half-space)[ohmm]:','Resistivity (body)[ohmm]:'};
      dlg_title='Body Dimensions';
      defaultanswer={'10','0','3','3','3','1','10','100'};
      options.Interpreter='tex';
      dim=inputdlg(prompt,dlg_title,[1 40],defaultanswer,options);

L=length(dim);
if L>0
xj=str2double(dim(1));
yj=str2double(dim(2));
h=str2double(dim(3));
l=str2double(dim(4));
w=str2double(dim(5));
d=str2double(dim(6));
rhom=str2double(dim(7));
rhoc=str2double(dim(8));
else
xj=nan;
yj=nan;
h=nan;
l=nan;
w=nan;
d=nan;
rhom=nan;
rhoc=nan;    
end
end